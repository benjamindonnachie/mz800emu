#!/bin/zsh
set -eu
task_root="$(cd "$(dirname "$0")/.." && pwd)"
build_dir="$task_root/build-records/mz800emu"
exec "$task_root/emulators/mz800emu/build-mac/build-mz700emu-pal/mz700emu-pal" \
  --home-dir "$task_root/emulators/mz800emu" \
  --cfg-dir "$build_dir/cpm3-suc-native/interactive-0.6.8" \
  --work-dir "$build_dir/disks" \
  --config "$build_dir/cpm3-suc-native/interactive-0.6.8/mz700.ini" \
  --no-first-run-windows
