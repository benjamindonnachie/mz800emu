#!/usr/bin/env python3
"""Independent PEHU banked CP/M3, using unoptimised SUC Native driver."""
from pathlib import Path
import argparse,base64,hashlib,json,os,pickle,pty,re,select,shutil,subprocess,sys,time,tarfile,tempfile
HERE=Path(__file__).resolve().parent; ROOT=HERE.parents[1]; BUILD=HERE/'build';BUILD.mkdir(exist_ok=True)
ap=argparse.ArgumentParser();ap.add_argument('--zxcc',type=Path,default=Path('/tmp/mz-cpm3-zxcc/bin/zxcc'));args=ap.parse_args();zxcc=args.zxcc
REF=ROOT/'cpm/cpm3-on2/reference';PYZ=ROOT/'cpm/gide/third_party/pyz80.py'
if not zxcc.exists():
 tools=Path(tempfile.mkdtemp(prefix='mz-pehu-zxcc-',dir='/tmp'))
 with tarfile.open(ROOT/'cpm/cpm3-on2/toolchain/zxcc-0.5.7.tar.gz') as archive:
  assert all(not Path(m.name).is_absolute() and '..' not in Path(m.name).parts for m in archive.getmembers())
  archive.extractall(tools,filter='data')
 source=tools/'zxcc-0.5.7';prefix=tools/'installed'
 for command in [['./configure','--prefix='+str(prefix)],['make','-j4'],['make','install']]:
  result=subprocess.run(command,cwd=source,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
  assert result.returncode==0,result.stdout.decode(errors='replace')
 zxcc=prefix/'bin/zxcc'

def run(cmd):
 p=subprocess.run(list(map(str,cmd)),cwd=BUILD,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
 (BUILD/'build.log').open('ab').write(p.stdout)
 assert p.returncode==0 and not re.search(rb'\[[^\r\n]*\?',p.stdout),p.stdout.decode(errors='replace')
 if any(str(x).endswith('rmac.com') for x in cmd): assert not re.search(rb'(?m)^[A-Z?] {2,}',p.stdout),p.stdout.decode(errors='replace')
 return p.stdout
(BUILD/'build.log').write_bytes(b'')
provenance=json.loads((HERE/'upstream-dri/provenance.json').read_text())
for name,digest in provenance['files'].items():assert hashlib.sha256((HERE/'upstream-dri'/name).read_bytes()).hexdigest()==digest,name
for name in ['cpm/suc-native/build/cpmldr.com','cpm/suc-native/build/cpmldr.sym','cpm/suc-native/build.py']:
 expected=json.loads((HERE/'loader-inputs.json').read_text())[name];assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==expected,name
for n in ['rmac.com','scb.rel']:
 shutil.copyfile(REF/n,BUILD/n)
shutil.copyfile(HERE/'upstream-dri/drlink.com',BUILD/'link.com')
for n in ['gencpm.com','ccp.com']:shutil.copyfile(REF/'utilities'/n,BUILD/n)
for n in ['cpmldr.com','cpmldr.sym']:shutil.copyfile(ROOT/'cpm/suc-native/build'/n,BUILD/n)
# Retain unoptimised source-built driver. Its only disk change is replacing
# two 128-byte LDIR copies with common cross-bank transfer calls.
# Head is extracted as a string literal without executing original build.py.
import ast
parsed=ast.parse((ROOT/'cpm/suc-native/build.py').read_text())
head=next(ast.literal_eval(n.value) for n in parsed.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='head' for t in n.targets))
disk=(HERE/'disk.asm').read_text()
disk=disk.replace('        LD BC,128\n        LDIR','        LD BC,128\n        CALL COMMON_TO_DMA',1)
pos=disk.index('write:');disk=disk[:pos]+disk[pos:].replace('        LD BC,128\n        LDIR','        LD BC,128\n        CALL COMMON_FROM_DMA',1)
body=head+'\n'.join((HERE/n).read_text() for n in ['banking.asm','keyboard.asm','suc-keyboard.asm','console.asm'])+'\n'+disk
body='COMMON_TO_DMA: EQU 0xD5D5\nCOMMON_FROM_DMA: EQU 0xD6D6\n'+body

def assemble(text,tag):
 blobs=[];symbols=[]
 for origin in (0,256,32768):
  src=BUILD/f'{tag}-{origin}.asm';src.write_text(f'ORG {origin}\n'+text)
  run([sys.executable,PYZ,'--obj='+str(src.with_suffix('.bin')),'--exportfile='+str(src.with_suffix('.symbols')),src])
  blobs.append(src.with_suffix('.bin').read_bytes());symbols.append(pickle.loads(src.with_suffix('.symbols').read_bytes()))
 a,b,c=blobs;assert len(a)==len(b)==len(c)
 relocs={i-1 for i,(x,y) in enumerate(zip(a,b)) if x!=y}
 expected=bytearray(a)
 for i in relocs:expected[i:i+2]=((int.from_bytes(a[i:i+2],'little')+32768)&65535).to_bytes(2,'little')
 assert expected==c
 return a,relocs,symbols[0]
a,ar,am=assemble(body,'native')
sys.path.insert(0,str(ROOT/'cpm/gide/tools'))
from media import SharpDSK,floppy
system=floppy(SharpDSK((ROOT/'cpm/gide/reference/CPM7004.dsk').read_bytes()).logical()).read('PCPM.SYS')
provenance=json.loads((HERE/'keyboard-provenance.json').read_text())
assert hashlib.sha256(system).hexdigest()==provenance['original_sys_sha256']
patches=json.loads((HERE/'keyboard-relocations.json').read_text())
expected=bytearray(system[patches['base']-0xC600:patches['end']-0xC600])
for r in patches['relocations']:
 at=r['offset'];assert int.from_bytes(expected[at:at+2],'little')==r['original']
 name,_,add=r['expression'].partition('+');value=am[name]+(int(add) if add else 0)
 expected[at:at+2]=value.to_bytes(2,'little')
for r in patches['nop_patches']:
 at=r['offset'];assert expected[at:at+r['bytes']]==bytes.fromhex(r['original']);expected[at:at+r['bytes']]=bytes(r['bytes'])
assert a[am['suc_blob']:am['suc_blob']+len(expected)]==expected
assert a[am['suc_macros']:am['suc_macros']+256]==system[0xDF00-0xC600:0xE000-0xC600]
assert a[am['suc_special_macros']:am['suc_special_macros']+128]==system[0xE000-0xC600:0xE080-0xC600]

external={'T_SELECT':'select','T_CONST':'console_status','T_CONIN':'console_input','T_CONOUT':'console_output','T_HOME':'disk_home','T_TRACK':'set_track','T_SECTOR':'set_sector','T_DMA':'set_dma','T_READ':'read','T_WRITE':'write','T_KEYINIT':'keyboard_init','T_CURSOR':'cursor_row','T_HELPER':'install_helper'}
markers={n:0xA500+am[v] for n,v in external.items()}
loader_driver=int(re.search(r'(?i)([0-9a-f]{4})\s+DRIVER',(BUILD/'cpmldr.sym').read_text())[1],16)
common='\n'.join(f'{n}: EQU {v}' for n,v in markers.items())+f'\nLOADER_CONSOLE: EQU {loader_driver+am["cursor_row"]}\nSCB_MXTPA: EQU 0xFE62\n'+(HERE/'common.asm').read_text()
c,cr,cm=assemble(common,'common')

def emit(data,relocs,base,fixes):
 lines=[base+':'];i=0
 while i<len(data):
  word=int.from_bytes(data[i:i+2],'little')
  if word in fixes and i+1<len(data):lines.append('\tdw\t'+fixes[word]);i+=2
  elif i in relocs:lines.append(f'\tdw\t{base}+0{word:04x}h');i+=2
  else:lines.append(f'\tdb\t0{data[i]:02x}h');i+=1
 return '\n'.join(lines)+'\n'
# Common references into the banked segment and vice versa remain LINK relocations.
cf={markers[n]:'driver+0%04xh'%am[v] for n,v in external.items()};cf[0xFE62]='@mxtpa'
af={0xD7D7:'cbbase+0%04xh'%cm['public_dpb'],0xD8D8:'cbbase+0%04xh'%cm['public_alv_c'],0xD9D9:'cbbase+0%04xh'%cm['public_alv_d'],0xD5D5:'cbbase+0%04xh'%cm['to_dma'],0xD6D6:'cbbase+0%04xh'%cm['from_dma']}
s='\textrn\t@mxtpa\n\tpublic\tcbbase,driver\n\tcseg\n'+emit(c,cr,'cbbase',cf)+'\tdseg\n'+emit(a,ar,'driver',af)+'\tend\n'
(BUILD/'bios.asm').write_bytes(s.replace('\n','\r\n').encode())
# Preserve the supplied N10 machine code and relocation maps verbatim.
pinned=json.loads((HERE/'reference/provenance.json').read_text())['files']
for name in ['RESBDOS3.SPR','BNKBDOS3.SPR']:
 raw=(HERE/'reference/zpm3n10'/name).read_bytes()
 assert hashlib.sha256(raw).hexdigest()==pinned[name]['sha256'],name
 assert raw[256:262]==b'SIMEON',name
 shutil.copyfile(HERE/'reference/zpm3n10'/name,BUILD/name.lower())
run([zxcc,'rmac.com','-bios']);run([zxcc,'link.com','-bnkbios3[os,b]=bios,scb'])
(BUILD/'gencpm.dat').unlink(missing_ok=True)
master,slave=pty.openpty();p=subprocess.Popen([str(zxcc),'gencpm.com'],cwd=BUILD,stdin=slave,stdout=slave,stderr=slave);os.close(slave)
answers=[('Create a new GENCPM.DAT','Y'),('Display Load Map','Y'),('Number of console columns','#80'),('Number of lines','#25'),('Backspace echoes','N'),('Rubout echoes','N'),('Initial default drive','C'),('Top page of memory','FF'),('Bank switched memory','Y'),('Common memory base page','C0'),('Long error messages','Y'),('Accept new system definition','Y')]
captured=bytearray();pending='';idx=0;end=time.monotonic()+20
try:
 while True:
  if time.monotonic()>end:raise TimeoutError('GENCPM waiting: '+pending)
  ready,_,_=__import__('select').select([master],[],[],.1)
  if ready:
   try:data=os.read(master,65536)
   except OSError:
    if p.poll() is not None:break
    raise
   if not data:break
   captured.extend(data);pending+=data.decode(errors='replace')
   if idx<len(answers) and answers[idx][0] in pending and '?' in pending:
    os.write(master,(answers[idx][1]+'\n').encode());idx+=1;pending=''
  elif p.poll() is not None:break
 assert p.wait()==0 and idx==len(answers),captured.decode(errors='replace')
finally:
 (BUILD/'gencpm-transcript.txt').write_bytes(captured);os.close(master)
 if p.poll() is None:p.kill();p.wait()
assert b'SYSTEM GENERATION DONE' in captured
symbols=(BUILD/'bnkbios3.sym').read_text();linked={n:int(x,16) for x,n in re.findall(r'([0-9A-F]{4})\s+(CBBASE|DRIVER)',symbols,re.I)}
report={'version':'0.1.0-zpm3-pehu-banked','common_raw_bytes':len(c),'native_bytes':len(a),'native_offsets':am,'common_offsets':cm,'linked':linked,'loader_driver':loader_driver,'common_boundary':0xC000,'system_bank':0,'application_bank':1,'shared_low_bytes':8192}
(BUILD/'build.json').write_text(json.dumps(report,indent=2)+'\n')
layout=[dict(module=n.decode(),base=int(x,16),bytes=int(y,16)) for n,x,y in re.findall(rb'(BNKBIOS3|RESBDOS3|BNKBDOS3)\s+SPR\s+([0-9A-F]+)H\s+([0-9A-F]+)H',captured)]
report['layout']=layout
report['common_base']=layout[0]['base'];report['driver_base']=layout[1]['base']
report['symbols']={n:report['driver_base']+v for n,v in am.items() if v<len(a)}
report['symbols'].update({n:report['common_base']+cm[v] for n,v in [('dpb','public_dpb'),('allocation_c','public_alv_c'),('allocation_d','public_alv_d')]})
report['common_symbols']={n:report['common_base']+v for n,v in cm.items()}
report['resident_bdos_base']=layout[2]['base'];report['normal_application_tpa_bytes']=layout[2]['base']-0x100
(BUILD/'build.json').write_text(json.dumps(report,indent=2)+'\n')
print(captured.decode(errors='replace'));print(report['linked'])
