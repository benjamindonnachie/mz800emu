"""Atomically replace application files after native checks and a full backup."""
from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
OUT = ROOT / 'build-records/mz800emu/zpm3-pehu-sharp-apps'
image = ROOT / 'build-records/mz800emu/disks/gide-zpm3-pehu-keyboard-fast-0.1.0.img'
manifest = json.loads((OUT / 'manifest.json').read_text())
for case in ('wordstar', 'compiler', 'database', 'spreadsheet', 'basic', 'pascal', 'utilities', 'games'):
    assert json.loads((OUT / (case + '-result.json')).read_text())['passed'], case
owners = subprocess.run(['lsof', '-t', str(image)], capture_output=True)
assert not owners.stdout, 'Close the Keyboard Fast emulator before replacing its disk image.'
before = image.read_bytes()
assert hashlib.sha256(before).hexdigest() == manifest['source_image']['sha256'], 'Working disk changed; rebase before installing.'
assert before == (OUT / 'restore-point/keyboard-fast-before-sharp-apps.img').read_bytes()
after = (OUT / 'factory.img').read_bytes()
assert hashlib.sha256(after).hexdigest() == manifest['image_sha256']
sys.path.insert(0, str(ROOT / 'cpm/gide/tools'))
from media import hard_volume
old = hard_volume(bytearray(before[:8388608]))
new = hard_volume(bytearray(after[:8388608]))
for name in ('CPM3.SYS', 'CCP.COM', 'ZCCP.COM', 'RTC.COM', 'DATE.COM', 'STARTZPM.COM', 'TCAP.Z3T', 'TPA.COM'):
    assert old.read(name) == new.read(name), name
assert after[16777216:] == before[16777216:]
assert image.read_bytes() == before
pending = image.with_name(image.name + '.sharp-apps-installing')
pending.write_bytes(after)
os.replace(pending, image)
assert image.read_bytes() == after
report = dict(passed=True, image=str(image), before_sha256=hashlib.sha256(before).hexdigest(),
    after_sha256=hashlib.sha256(after).hexdigest(), backup=str(OUT / 'restore-point/keyboard-fast-before-sharp-apps.img'),
    installed_files=len(manifest['files']), removed_old_application_files=len({(r['user'], r['name']) for r in manifest['removed']}),
    retained_files=len(manifest['retained']), kernel_ccp_rtc_boot_unchanged=True, tpa_bytes=60672)
(OUT / 'installation.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report, indent=2))
