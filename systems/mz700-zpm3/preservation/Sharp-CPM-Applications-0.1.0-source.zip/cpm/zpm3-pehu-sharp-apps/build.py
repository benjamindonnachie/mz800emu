"""Application-only replacement from pinned Sharp-archive CP/M RAW images."""
from pathlib import Path
import hashlib
import json
import sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
OUT = ROOT / 'build-records/mz800emu/zpm3-pehu-sharp-apps'
REF = HERE / 'reference'
PAY = OUT / 'payload'
OUT.mkdir(parents=True, exist_ok=True)
sys.path.insert(0, str(ROOT / 'cpm/gide/tools'))
from media import Volume, hard_volume

base = (REF / 'base.img').read_bytes()
assert hashlib.sha256(base).hexdigest() == json.loads((REF / 'base.json').read_text())['sha256']
image = bytearray(base)
volumes = {drive: hard_volume(image[offset:offset + 8388608])
           for drive, offset in [('C', 0), ('D', 8388608)]}
before = {drive: {(e[0], v.name(e)): v.read(v.name(e), e[0])
                  for _, e in v.directory() if e[0] < 16}
          for drive, v in volumes.items()}
removed = []
records = []
old = json.loads((REF / 'old-app-manifest.json').read_text())['files']
owned = {(r['user'], r['name']) for r in old if r['drive'] == 'D'}
for index, entry in list(volumes['D'].directory()):
    if (entry[0], volumes['D'].name(entry)) in owned:
        removed.append(dict(user=entry[0], name=volumes['D'].name(entry)))
        volumes['D'].data[index * 32] = 0xE5

def add(drive, user, name, payload, origin):
    path = PAY / drive / str(user) / name
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(payload)
    if (user, name) in before[drive] and not (drive == 'D' and (user, name) in owned):
        assert name in ('APPS.COM', 'APPS.TXT') or before[drive][user, name] == payload, (
            'Unowned file collision', drive, user, name)
    volumes[drive].write(name, payload, user)
    records.append(dict(drive=drive, user=user, name=name, bytes=len(payload),
                        sha256=hashlib.sha256(payload).hexdigest(), origin=origin))

def text(drive, user, name, contents):
    add(drive, user, name, contents.replace('\n', '\r\n').encode('ascii') + b'\x1a', 'Local instructions/example')

for source in json.loads((REF / 'sources.json').read_text()):
    payload = (REF / source['file']).read_bytes()
    assert hashlib.sha256(payload).hexdigest() == source['sha256']
    # TZFS config/diskdefs MZ80A-1440:2048byte blocks,128dir entries,
    # no boot tracks,720blocks,16bit block pointers and EXM0.
    volume = Volume(bytearray(payload), 2048, 720, 128, exm=0)
    files = sorted({(e[0], volume.name(e)) for _, e in volume.directory() if e[0] < 16})
    for user, name in files:
        assert user == 0
        if name == 'CD.COM':
            continue  # Collection-specific drive switcher, not our C/D BIOS.
        data = volume.read(name)
        configured = HERE / 'configured' / str(source['user']) / name
        if configured.exists():
            data = configured.read_bytes()
            origin = source['file'] + ':' + name + '; terminal configuration, original preserved'
        else:
            origin = source['file'] + ':' + name
        add('D', source['user'], name, data, origin)

installed = {(r['user'], r['name']) for r in records if r['drive'] == 'D'}
for path in sorted((HERE / 'configured').glob('*/*')):
    user = int(path.parent.name)
    if (user, path.name) not in installed:
        add('D', user, path.name, path.read_bytes(), 'Native terminal installation/active template/sample; see configured.json')

text('D', 0, 'SHARPNEW.TXT', 'Sharp MZ-700 ZPM3 with applications from the Sharp CP/M archive.\nWordStar archive version and GIDE storage test.\n')
text('D', 2, 'HELLO.C', '#include <stdio.h>\nint main(void) { printf("HI-TECH C ON SHARP: 42\\n"); return 0; }\n')
text('D', 2, 'IOCHECK.C', '''#include <stdio.h>
int main(void) {
 FILE *f; int i,j,c; long n=0;
 f=fopen("HICTEST.DAT","wb"); if(!f) return 1;
 for(i=0;i<80;i++) for(j=0;j<1024;j++) { if(fputc((i+j)&255,f)==EOF) return 2; n++; }
 if(fclose(f)) return 3;
 f=fopen("HICTEST.DAT","rb"); if(!f) return 4;
 for(i=0;i<80;i++) for(j=0;j<1024;j++) { c=fgetc(f); if(c!=((i+j)&255)) return 5; }
 fclose(f); printf("HI-TECH IO PASS: %ld bytes\\n",n); return 0;
}
''')
text('D', 5, 'HELLO.PAS', "program Hello;\nbegin writeln('TURBO PASCAL ON SHARP: 42') end.\n")
text('D', 4, 'BDEMO.BAS', '10 PRINT "BASCOM ON SHARP:42"\n20 END\n')
guide = (HERE / 'APPS.TXT').read_text()
for drive, user in [('C', 0)] + [('D', u) for u in range(7)]:
    text(drive, user, 'APPS.TXT', guide)
message = b'Sharp archive CP/M applications\r\nD0: WordStar3.30  D1: dBASEII  D2: Hi-TechC\r\nD3: Multiplan  D4: MBASIC/BASCOM  D5: TurboPascal3\r\nD6: CP/M games from Sharp archive\r\nTYPE APPS.TXT for instructions; C0: returns to system.\r\n$'
add('C', 0, 'APPS.COM', bytes.fromhex('1109010e09cd0500c9') + message, 'Local BDOS9 application index')

retained = []
for drive, offset in [('C', 0), ('D', 8388608)]:
    volume = volumes[drive]
    for (user, name), data in before[drive].items():
        if name in ('APPS.COM', 'APPS.TXT') or (drive == 'D' and (user, name) in owned):
            continue
        assert volume.read(name, user) == data, (drive, user, name)
        retained.append(dict(drive=drive, user=user, name=name, sha256=hashlib.sha256(data).hexdigest()))
    image[offset:offset + 8388608] = volume.data
assert image[16777216:] == base[16777216:]
for name in ('CPM3.SYS', 'CCP.COM', 'RTC.COM', 'DATE.COM', 'STARTZPM.COM', 'TCAP.Z3T'):
    assert volumes['C'].read(name) == before['C'][0, name]
(OUT / 'factory.img').write_bytes(image)
(OUT / 'manifest.json').write_text(json.dumps(dict(passed=True, source_image=json.loads((REF / 'base.json').read_text()),
    image_sha256=hashlib.sha256(image).hexdigest(), files=records, removed=removed,
    retained=retained, kernel_ccp_rtc_boot_unchanged=True, tpa_bytes=60672), indent=2) + '\n')
print('Prepared', len(records), 'files; removed', len({(r['user'],r['name']) for r in removed}), 'old application files; retained', len(retained))
