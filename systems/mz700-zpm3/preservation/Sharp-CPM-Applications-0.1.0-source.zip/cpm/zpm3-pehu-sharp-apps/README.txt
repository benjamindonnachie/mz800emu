Sharp archive applications for MZ-700 ZPM3 Keyboard Fast
19 October2026

Installed on the existing Keyboard Fast working GIDE disk. Use:
 emulators/Start MZ-700 ZPM3 ZCCP PEHU Keyboard Fast - TEST.command
Press F and Return at the Sharp monitor. Type APPS at the C0 prompt, or
TYPE APPS.TXT for command notes. Select D0:, D1:, etc.; C0: returns to tools.

D0 WordStar3.30, supplied WSHEATH/H19 binary aliased WS.COM. The documented
   DEFDSK field at memory02B9/file01B9 is changed fromA(1) toD(4) for overlays.
   WS SHARPNEW.TXT opens the sample; Ctrl-K X saves and exits.
D1 dBASEII2.41. DBASE; Return skips optional date. QUIT exits.
D2 Hi-TechC3.09. C HELLO.C then HELLO. C IOCHECK.C then IOCHECK tests81,920
   bytes of I/O. Compilation involves several passes; wait for the prompt.
D3 Microsoft Multiplan1.06, configured natively for DEC VT52. MP starts it.
   TL then SHARP loads the example42+58=100. V enters a value, GR selects
   row/column, Ctrl-I moves between fields, TS saves, Q then Y quits.
D4 Microsoft BASIC5.21 and BASCOM5.30a, libraries, M80 and L80.
   MBASIC, PRINT 6*7, SYSTEM. BASCOM =BDEMO /O/E then L80 BDEMO,BDEMO/N/E
   links the example; BDEMO runs it. /O selects standalone compilation as
   documented in the archived BASCOM2.HLP; the default needs a loader/header.
D5 Turbo Pascal3.00A, configured natively through TINST for ADM3A.
   TURBO; N skips error messages. W then HELLO.PAS selects source; R compiles
   and runs it. Q exits to CP/M.
D6 CP/M games, including Zork1..3, Adventure, Ladder, Othello and Sargon.
   ZORK1 startup/LOOK/QUIT was tested. Other games are original archive copies
   and have not all been tested or configured for this terminal.

Source and compatibility
Original programme bytes were extracted from pinned1.44MB RAW images in:
 /Volumes/EXTERNAL/Sharp Archive/Software/Sharp-MZ-Catalogue/sources/
 sharp-cpm-ports/extracted/CPM/1M44/RAW/
These are Philip Smart's Sharp/TZFS CP/M collection; its source build script
credits Grant Searle's collection and other CP/M archives. Distribution on a
Sharp disk does not establish a Sharp-specific hardware patch. No MZ-800
Unicard tools, operating systems or BIOS replacements were installed.
The original images, hashes and native configuration results are retained in
reference/, configured/ and configured.json. The explicit disk definition is
TZFS MZ80A-1440:2048byte blocks,128directory entries, no boot tracks, EXM0.
WordStar4 was explored but not selected after an unresolved configuration/edit
workflow. Its original image remains in reference/; working WordStar3.30 was
selected and tested instead. No generic Rlee/Commodore programme binaries were
substituted for the selected archive application executables.

What changed
178 programme/resource/example/index files installed;100 previous application
files removed by their recorded ownership manifest. System utilities and55
other files, including user/test files outside that ownership list, retained
byte-for-byte. The previous Monopoly listing remains only in the saved prior
image; it was not repaired or copied into this replacement collection.
CPM3.SYS, CCP/ZCCP, RTC/DATE, TCAP, TPA utilities and boot-tail bytes are
unchanged. The BIOS/BDOS source and existing factory-release archives are
unchanged. Working-image application TPA remains60,672bytes (59.25KiB).

Tests
Native checks pass for WordStar edit/save/cold reopen; indexed dBASE records,
sum and cold reopen; Hi-Tech compile/link and81,920byte I/O verified on host;
Multiplan dependent formula/save/cold reload; BASIC interpreter arithmetic and
BASCOM/L80 compile/link/run; Turbo Pascal compile/run; DATE/PIP/TPA; and Zork.
No whole-game completion or compatibility claim for every bundled game.

Restore
Exact previous working image, launcher and profile with SHA256 hashes:
 build-records/mz800emu/zpm3-pehu-sharp-apps/restore-point/
 keyboard-fast-before-sharp-apps.img
Close the emulator before replacing its working image with that saved image:
 build-records/mz800emu/disks/gide-zpm3-pehu-keyboard-fast-0.1.0.img
The profile and launcher were not changed by this installation. Later user
changes are not part of that earlier snapshot.

Reproduce and preservation
 python3 cpm/zpm3-pehu-sharp-apps/build.py
 python3 cpm/zpm3-pehu-sharp-apps/test.py <case>
Cases: wordstar,compiler,database,spreadsheet,basic,pascal,utilities,games.
 install.py checks all results, confirms the working image is closed and
unchanged from its captured base, verifies kernel/boot preservation, then
installs atomically. It deliberately refuses an already changed source image.
 package.py proves source-ZIP-only rebuilding of the entire replacement image
and all178 payload files. Source/media/evidence packages and SHA256 manifests
are under build-records/mz800emu/zpm3-pehu-sharp-apps/preservation/0.1.0.
Existing programme copyrights and distribution terms remain applicable.
