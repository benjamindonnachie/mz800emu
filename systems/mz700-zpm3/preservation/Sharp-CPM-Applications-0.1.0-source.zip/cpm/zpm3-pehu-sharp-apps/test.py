"""Native application checks on disposable copies of the Sharp payload."""
from pathlib import Path
import hashlib
import json
import sys
from session import Session, ROOT, hard_volume

OUT = ROOT / 'build-records/mz800emu/zpm3-pehu-sharp-apps'
case = sys.argv[1]
evidence = {'case': case}
s = None

def volume(image):
    return hard_volume(bytearray(image.read_bytes()[8388608:16777216]))

try:
    s = Session('test-' + case)
    if case == 'wordstar':
        s.command('D0:')
        assert 'Sharp MZ-700' in s.command('WS SHARPNEW.TXT', 15000)
        s.text('ARCHIVE VERIFIED ')
        s.ctrl('K'); s.text('X'); s.run(3000)
        assert s.capture('saved').endswith('D0>')
        image = s.image; s.close(); s = None
        data = volume(image).read('SHARPNEW.TXT')
        assert b'archive verified' in bytes(x & 127 for x in data).lower()
        s = Session('test-wordstar-cold', source=image)
        s.command('D0:')
        assert 'archive verified' in s.command('WS SHARPNEW.TXT', 15000).lower()
        s.screenshot('cold-reopened')
        s.ctrl('K'); s.text('X'); s.run(3000)
        evidence.update(version='3.30', terminal='HeathH19/VT52', overlay_drive='D', edit_save_cold_reopen=True)
    elif case == 'compiler':
        s.command('D2:')
        assert s.command('C -V HELLO.C', 40000).endswith('D2>')
        assert 'HI-TECH C ON SHARP: 42' in s.command('HELLO')
        assert s.command('C -V IOCHECK.C', 40000).endswith('D2>')
        assert 'HI-TECH IO PASS: 81920 bytes' in s.command('IOCHECK', 20000)
        s.screenshot('native-compile-and-io')
        image = s.image; s.close(); s = None
        data = volume(image).read('HICTEST.DAT', 2)
        assert data == bytes((i + j) & 255 for i in range(80) for j in range(1024))
        evidence.update(compiler='Hi-Tech3.09', native_compile_link_run=True, io_bytes=len(data),
                        io_sha256=hashlib.sha256(data).hexdigest())
    elif case == 'database':
        for command in ('D1:', 'DBASE', '', 'CREATE ARCTEST', 'NAME,C,20', 'SCORE,N,6,0', '', 'N',
                        'USE ARCTEST', 'APPEND BLANK', 'REPLACE NAME WITH "SHARP", SCORE WITH 42',
                        'APPEND BLANK', 'REPLACE NAME WITH "GIDE", SCORE WITH 58',
                        'INDEX ON NAME TO ARCTEST', 'GO TOP', '? NAME', 'SUM SCORE'):
            s.command(command, 3000)
        assert 'gide' in s.screen().lower() and '100' in s.screen()
        assert s.command('QUIT').endswith('D1>')
        image = s.image; s.close(); s = None
        assert len(volume(image).read('ARCTEST.DBF', 1)) > 0
        assert len(volume(image).read('ARCTEST.NDX', 1)) > 0
        s = Session('test-database-cold', source=image)
        for command in ('D1:', 'DBASE', '', 'USE ARCTEST INDEX ARCTEST', 'LIST', 'SUM SCORE'):
            s.command(command, 3000)
        assert all(word in s.screen().lower() for word in ('gide', 'sharp', '100'))
        s.screenshot('indexed-cold-reopen'); s.command('QUIT')
        evidence.update(version='2.41', indexed_records=2, total=100, cold_reopen=True)
    elif case == 'spreadsheet':
        s.command('D3:'); s.command('MP')
        assert 'Multiplan:' in s.screen()
        s.text('TL'); s.command('SHARP'); assert '100' in s.screen()
        s.text('GR'); s.ctrl('I'); s.text('1'); s.key('RETURN')
        s.text('V43'); s.key('RETURN'); s.run()
        assert '101' in s.screen(), s.screen()
        s.text('TS'); s.command('VERIFY'); s.text('QY'); s.run(3000)
        assert s.capture('saved').endswith('D3>')
        image = s.image; s.close(); s = None
        assert len(volume(image).read('VERIFY.', 3)) > 0
        s = Session('test-spreadsheet-cold', source=image)
        s.command('D3:'); s.command('MP'); s.text('TL'); s.command('VERIFY')
        assert '101' in s.screen(); s.screenshot('formula-cold-reopen')
        s.text('QY'); s.run(3000)
        evidence.update(version='Multiplan1.06', terminal='VT52', dependent_formula=101, save_cold_reload=True)
    elif case == 'basic':
        s.command('D4:'); assert 'BASIC-80 Rev. 5.21' in s.command('MBASIC')
        assert ' 42' in s.command('PRINT 6*7'); assert s.command('SYSTEM').endswith('D4>')
        assert '00000 Fatal Error(s)' in s.command('BASCOM =BDEMO /O/E', 15000)
        assert s.command('L80 BDEMO,BDEMO/N/E', 15000).endswith('D4>')
        assert 'BASCOM ON SHARP:42' in s.command('BDEMO')
        s.screenshot('interpreter-compiler')
        evidence.update(interpreter='5.21', compiler='5.30a', arithmetic=True, native_compile_link_run=True)
    elif case == 'pascal':
        s.command('D5:'); assert 'ADM 3A' in s.command('TURBO')
        s.text('N'); s.run(); s.text('W'); s.command('HELLO.PAS')
        s.text('R'); s.run(5000)
        assert 'TURBO PASCAL ON SHARP: 42' in s.capture('run')
        s.screenshot('native-compile-run'); s.text('Q'); s.run(3000)
        assert s.screen().endswith('D5>')
        evidence.update(version='3.00A', terminal='ADM3A', compile_run=True)
    elif case == 'utilities':
        assert 'WordStar3.30' in s.command('APPS')
        assert '20' in s.command('DATE')
        assert 'Space:' in s.command('SHOW D:')
        s.command('PIP D:ARCOPY.TXT=C:APPS.TXT[V]', 5000)
        image = s.image
        expected = hard_volume(bytearray(image.read_bytes()[:8388608])).read('APPS.TXT')
        assert volume(image).read('ARCOPY.TXT', 0) == expected
        s.screenshot('utilities'); evidence.update(rtc=True, host_verified_pip=True)
    elif case == 'games':
        s.command('D6:'); text = s.command('ZORK1', 6000)
        assert 'ZORK' in text.upper() or 'West of House' in text
        s.command('LOOK'); s.screenshot('zork')
        s.command('QUIT'); s.command('Y'); s.run(3000)
        evidence.update(zork_start_and_look=True, other_games='Archive copies, not all tested')
    else:
        raise ValueError(case)
    if s:
        s.command('C0:TPA')
        assert int.from_bytes(s.mem(0x8002, 2), 'little') == 60672
    evidence.update(passed=True, kernel_unchanged=True, tpa_bytes=60672)
    (OUT / (case + '-result.json')).write_text(json.dumps(evidence, indent=2) + '\n')
    print('PASS', case, evidence, flush=True)
finally:
    if s:
        s.close()
