"""Preserve the application-only source/media/evidence and rebuild offline."""
from pathlib import Path
import hashlib
import json
import subprocess
import sys
import tempfile
import zipfile

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
OUT = ROOT / 'build-records/mz800emu/zpm3-pehu-sharp-apps'
PACK = OUT / 'preservation/0.1.0'
PACK.mkdir(parents=True, exist_ok=True)
files = [p for p in HERE.rglob('*') if p.is_file() and '__pycache__' not in p.parts]
files += [ROOT / 'cpm/gide/tools/media.py']

def archive(path, paths):
    with zipfile.ZipFile(path, 'w', zipfile.ZIP_DEFLATED) as z:
        for p in sorted(set(paths)):
            z.write(p, p.relative_to(ROOT))
    with zipfile.ZipFile(path) as z:
        assert z.testzip() is None

source = PACK / 'Sharp-CPM-Applications-0.1.0-source.zip'
archive(source, files)
temp = Path(tempfile.mkdtemp(prefix='sharp-apps-rebuild-', dir='/tmp'))
with zipfile.ZipFile(source) as z:
    z.extractall(temp)
run = subprocess.run([sys.executable, str(temp / 'cpm/zpm3-pehu-sharp-apps/build.py')],
                     cwd=temp, capture_output=True)
(PACK / 'rebuild.log').write_bytes(run.stdout + run.stderr)
assert run.returncode == 0, run.stderr.decode(errors='replace')
rebuilt = temp / 'build-records/mz800emu/zpm3-pehu-sharp-apps'
assert (rebuilt / 'factory.img').read_bytes() == (OUT / 'factory.img').read_bytes()
manifest = json.loads((OUT / 'manifest.json').read_text())
for r in manifest['files']:
    name = Path('payload') / r['drive'] / str(r['user']) / r['name']
    assert (rebuilt / name).read_bytes() == (OUT / name).read_bytes()
proof = dict(passed=True, source_zip_only=True, factory_image_byte_identical=True,
             payload_files_byte_identical=len(manifest['files']),
             image_sha256=manifest['image_sha256'])
(PACK / 'clean-rebuild.json').write_text(json.dumps(proof, indent=2) + '\n')
archive(PACK / 'Sharp-CPM-Applications-0.1.0-media.zip', [OUT / 'factory.img', OUT / 'manifest.json', HERE / 'APPS.TXT'])
evidence = [p for p in OUT.rglob('*') if p.is_file() and 'preservation' not in p.parts
            and 'restore-point' not in p.parts and 'payload' not in p.parts
            and p.suffix in ('.json', '.png', '.log')]
archive(PACK / 'Sharp-CPM-Applications-0.1.0-evidence.zip', evidence + [PACK / 'clean-rebuild.json'])
summary = {p.name: dict(bytes=p.stat().st_size, sha256=hashlib.sha256(p.read_bytes()).hexdigest())
           for p in PACK.glob('*.zip')}
(PACK / 'packages.json').write_text(json.dumps(summary, indent=2) + '\n')
print('PASS source-only image rebuild and', len(manifest['files']), 'payloads; three ZIPs verified.')
